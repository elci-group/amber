# Roadmap: 80% → 95% Line Coverage

## Current state

- Coverage: **80.17%** (1,202 / 1,498 lines)
- Target: **95%** (≈1,423 lines)
- Gap: **≈221 uncovered lines**

The project is already at S-grade (≥80%). Pushing to 95% requires attacking the remaining high-density uncovered modules rather than chasing one-liners.

## Where the uncovered lines are

| Module | Lines | Covered | Uncovered | Notes |
|--------|-------|---------|-----------|-------|
| `src/main.rs` | 178 | 128 | **50** | CLI entry, error branches, `--online` feature gate, banner |
| `src/analysis/usage.rs` | 304 | 266 | **38** | Visitor branches for macros, attrs, method calls, imports |
| `src/metadata/online.rs` | 37 | 0 | **37** | crates.io HTTP calls; gated behind `online` feature |
| `src/metadata/rustsec.rs` | 66 | 44 | **22** | `fetch_batch`, `count_advisories`, git error paths |
| `src/analysis/repo.rs` | 85 | 59 | **26** | Transitive dep lookup, path/git registry source branches |
| `src/reporting/formatters.rs` | 256 | 232 | **24** | JSON/PR/SARIF reporters, score-bar color branches |
| `src/scoring/classifier.rs` | 148 | 136 | **12** | Score/risk branches that need tailored fixtures |
| `src/replacement/templates.rs` | 94 | 81 | **13** | Format-string literal lines, default stub branches |
| `src/config/mod.rs` | 20 | 18 | **2** | `Policy::is_required` |

Total addressable real code: **≈224 lines**. Hitting 95% is feasible, but several modules need **testability refactors** first.

## Strategy overview

The work is split into four phases. Each phase lists the estimated line-coverage gain and the files to touch.

---

## Phase 1 — CLI and main.rs error paths (+35–45 lines)

**Goal:** Exercise the branches in `run()` and `build_analyzer()` without needing a network connection.

### Actions

1. **Integration tests for CLI commands**
   - Add `tests/cli_list.rs`, `tests/cli_score.rs`, `tests/cli_replace.rs` using `assert_cmd` / `std::process::Command`.
   - Run against `tests/fixtures/sample_project`.
   - Each command hits a different arm of `run()`.
   - *Estimated gain: +25 lines in `main.rs`*.

2. **Error-path integration tests**
   - Invalid manifest path → covers `run()` error branch (`main.rs:191–199`).
   - Missing crate for `score` → covers `get_dependency()` error propagation.
   - Non-existent project directory → covers `RepositoryAnalyzer::new` error.
   - *Estimated gain: +10 lines*.

3. **Banner test**
   - Extract `print_banner()` output to a string-returning helper or capture stdout in an integration test.
   - Currently `print_banner()` is 0/5.
   - *Estimated gain: +5 lines*.

### Notes

- The `--online` branch in `build_analyzer()` is compiled only with the `online` feature. To cover it, either:
  - Run integration tests with `--features online` and accept network flakiness, or
  - Refactor `build_analyzer()` to accept a provider factory so tests can inject an offline mock even when the feature is enabled.
- The `#[cfg(not(feature = "online"))]` bail branch can be tested by compiling without the feature and invoking `--online` in an integration test.

---

## Phase 2 — Analysis modules: usage.rs and repo.rs (+45–55 lines)

### usage.rs

The visitor pattern has many small branches. Add targeted Rust source fixtures and assert the recorded call sites.

| Uncovered block | Test fixture needed | Lines |
|-----------------|---------------------|-------|
| `visit_stmt` macro statement (`Stmt::Macro`) | File with `macro_rules!` usage of a tracked crate | 2 |
| `check_macro` empty path / non-crate macro | Macro from std or untracked crate | 2 |
| `check_attribute` imported-name branch | `use serde::Serialize; #[derive(Serialize)]` | 4 |
| `check_derive_attribute` parsing | Already partly covered; add failure path | 3 |
| `visit_expr` `MethodCall` receiver/imported branches | `alias.method()` and trait-method usage | 7 |
| `collect_imports` glob/group/rename | Already partly covered; add combined `use crate::{A,B}` | 4 |
| `guess_item_kind` macro `ends_with('!')` | `use foo::bar!;` | 1 |
| `discover_source_files` examples/tests/benches traversal | Fixture project with `examples/` and `tests/` dirs | 4 |

**Action:** Create small fixture crates under `tests/fixtures/` with precise usage patterns and assert `UsageAnalyzer` output.

*Estimated gain: +25–30 lines.*

### repo.rs

| Uncovered block | Test approach | Lines |
|-----------------|---------------|-------|
| Path-sourced dependency | Fixture with a path dependency | 4 |
| Non-crates.io registry source | Hard to fixture; consider mock metadata | 3 |
| Transitive dep lookup edge cases | Fixture where node has no matching package | 5 |
| `get_dependency` error message | Already covered | — |
| `estimate_loc` with multiple targets | Add fixture with bin+lib targets | 2 |

*Estimated gain: +10–15 lines.*

---

## Phase 3 — Metadata mocking: online.rs and rustsec.rs (+50–60 lines)

This is the highest-leverage refactor. Both modules currently perform real I/O, making them either uncovered (`online.rs`) or partially covered only on success paths.

### online.rs

**Refactor:**

```rust
pub struct CratesIoProvider {
    client: ureq::Agent,
    base_url: String,
}

impl CratesIoProvider {
    pub fn new() -> Self { Self::with_base_url(CRATES_IO_API) }
    pub fn with_base_url(base_url: impl Into<String>) -> Self { ... }
}
```

Then tests can point `CratesIoProvider::with_base_url(local_test_server_url)` to a tiny HTTP server (e.g., `tiny_http` or a `tokio` test server) returning a JSON response.

Alternatively, inject a `fetch_crate` trait object for full isolation.

**Test cases:**
- Successful fetch with downloads + versions.
- JSON parse error.
- HTTP error.
- Default metadata fallback.

*Estimated gain: +35 lines (all of `online.rs`).*

### rustsec.rs

**Refactor:**

Extract a `GitRunner` trait or closure so `RustSecSource` can run git without the real CLI:

```rust
struct RustSecSource {
    cache_dir: PathBuf,
    db: OnceLock<Option<Database>>,
    git_runner: Box<dyn Fn(&Path, &[&str]) -> Result<(), RustSecError> + Send + Sync>,
}
```

**Test cases:**
- Clone success (mock returns Ok).
- Clone failure (mock returns Err) → covers `warn!` and `None` path.
- Pull success / failure.
- `fetch_batch` with a populated mock database.
- `count_advisories` with a temp advisory DB.

*Estimated gain: +20–25 lines.*

---

## Phase 4 — Reporters and scoring edge cases (+30–40 lines)

### reporting/formatters.rs

| Uncovered block | Test approach | Lines |
|-----------------|---------------|-------|
| `ConsoleReporter` validation-result red branch | Score with validation result not starting with "cargo check passed" | 1 |
| `score_bar` 0–25 and 26–50 branches | Scores 10, 40 | 2 |
| `JsonReporter::generate_json` | Call with sample deps/scores | 24 |
| `PrReporter::generate_pr_body` critical section | Add SecurityCritical score to input | 6 |
| `SarifReporter::generate_sarif` replaceable + unused branches | Call with sample data | 18 |
| `Default` impls for reporters | One-liner tests | 3 |

**Action:** Unit-test each reporter with small, hand-built inputs. Most are pure functions and trivial to test.

*Estimated gain: +20–25 lines.*

### scoring/classifier.rs

| Uncovered block | Test approach | Lines |
|-----------------|---------------|-------|
| `score_maintenance_burden` / `score_testability` branches | Tailored usage fixtures | 4 |
| `confidence_score` high-usage branches | Many APIs, many files, many calls | 4 |
| `calculate_overall_score` FREQUENTLY_REPLACEABLE boost | Use a known frequently-replaceable crate | 3 |
| `classify` LowRisk / HighRisk / DoNotReplace ranges | Construct scores by manipulating dimensions | 6 |

*Estimated gain: +10–15 lines.*

---

## Execution order recommendation

1. **Start with Phase 4** (reporters + scoring). It is pure code, no refactors, and gives fast, deterministic gains.
2. **Phase 2** (analysis fixtures). Builds on existing fixture infrastructure.
3. **Phase 1** (CLI integration). Adds integration test infrastructure; establishes patterns for end-to-end tests.
4. **Phase 3** (metadata mocking). Largest structural change; do it after the easier phases so the coverage buffer is smaller.

## Expected outcome

| Phase | Estimated gain | Cumulative coverage |
|-------|---------------|---------------------|
| Baseline | — | 80.17% |
| Phase 4 | +30–40 | ~82.5–83% |
| Phase 2 | +45–55 | ~85.5–87% |
| Phase 1 | +35–45 | ~88–89% |
| Phase 3 | +50–60 | **~92–94%** |

The last 1–3% to reach 95% comes from:

- Testing the `#[cfg(not(feature = "online"))]` bail branch.
- Covering the remaining `main.rs` edge cases (verbose level branches, path selection).
- A few stubborn `templates.rs` format-string lines that may require empty-vs-populated usage fixtures.

## Risk / quality guardrails

- Keep `tarpaulin.toml` exclusions for `src/replacement/template_data/*`; those are data, not logic.
- Do **not** chase coverage by testing trivial getters/setters unless it meaningfully improves the metric.
- Every new test must run under `--offline` (no network) so CI stays deterministic.
- Maintain `cargo clippy --all-targets --all-features -- -W clippy::pedantic -W clippy::nursery -D warnings` cleanliness.
- After each phase, run `cargo tarpaulin --all-targets --all-features --out Stdout` to validate progress before moving on.

## Stop criteria

- Target: **≥95% line coverage**.
- Hard stop: do not refactor purely for coverage if it degrades API design (e.g., exposing internals that should stay private). Prefer integration tests or small, well-justified refactorings over test-only hacks.
