//! amber_env_logger — Minimal replacement for `env_logger`
//!
//! Initializes logging based on RUST_LOG environment variable.

use std::env;

/// Initialize the logger from the environment
pub fn init() {
    let rust_log = env::var("RUST_LOG").unwrap_or_else(|_| "info".to_string());
    let level = parse_level(&rust_log);
    crate::log::set_max_level(level);
}

/// Builder pattern for configuration
pub struct Builder {
    level: crate::log::Level,
}

impl Builder {
    pub fn new() -> Self {
        Self {
            level: crate::log::Level::Info,
        }
    }

    pub fn parse_filters(mut self, filters: &str) -> Self {
        self.level = parse_level(filters);
        self
    }

    pub fn init(self) {
        crate::log::set_max_level(self.level);
    }
}

impl Default for Builder {
    fn default() -> Self {
        Self::new()
    }
}

fn parse_level(s: &str) -> crate::log::Level {
    match s.to_lowercase().as_str() {
        "error" => crate::log::Level::Error,
        "warn" => crate::log::Level::Warn,
        "info" => crate::log::Level::Info,
        "debug" => crate::log::Level::Debug,
        "trace" => crate::log::Level::Trace,
        _ => crate::log::Level::Info,
    }
}

