use crate::analysis::types::CrateUsage;

/// Code templates for common replacement scenarios
pub struct ReplacementTemplate<'a> {
    crate_name: &'a str,
    usage: &'a CrateUsage,
}

#[allow(clippy::unused_self)]
impl<'a> ReplacementTemplate<'a> {
    #[must_use]
    pub const fn for_crate(crate_name: &'a str, usage: &'a CrateUsage) -> Self {
        Self { crate_name, usage }
    }

    #[must_use]
    pub fn generate_code(&self) -> String {
        match self.crate_name {
            "lazy_static" => self.replace_lazy_static(),
            "once_cell" => self.replace_once_cell(),
            "itertools" => self.replace_itertools(),
            "colored" | "owo-colors" | "yansi" | "ansi_term" => self.replace_colored(),
            "anyhow" => self.replace_anyhow(),
            "thiserror" => self.replace_thiserror(),
            "log" => self.replace_log(),
            "env_logger" => self.replace_env_logger(),
            "humantime" => self.replace_humantime(),
            "home" | "dirs" => self.replace_home_dirs(),
            "either" => self.replace_either(),
            "tap" => self.replace_tap(),
            "cfg-if" => self.replace_cfg_if(),
            "maplit" => self.replace_maplit(),
            "byteorder" => self.replace_byteorder(),
            "chrono" => self.replace_chrono(),
            "regex" => self.replace_regex(),
            _ => self.generate_generic_stub(),
        }
    }

    fn replace_lazy_static(&self) -> String {
        include_str!("template_data/lazy_static.rs").to_string()
    }

    fn replace_once_cell(&self) -> String {
        include_str!("template_data/once_cell.rs").to_string()
    }

    fn replace_itertools(&self) -> String {
        let mut code = r"//! amber_itertools — Replacement for common `itertools` functions
//!
//! Only implements the subset of itertools actually used.

pub trait AmberItertools: Iterator + Sized {
"
        .to_string();

        // Only implement methods that are actually used
        for item in &self.usage.imported_items {
            match item.name.as_str() {
                "join" => {
                    code.push_str(
                        r#"
    /// Join iterator elements with a separator
    fn join(&mut self, sep: &str) -> String
    where
        Self::Item: std::fmt::Display,
    {
        use std::fmt::Write;
        let mut result = String::new();
        let mut first = true;
        for item in self {
            if !first {
                result.push_str(sep);
            }
            write!(result, "{}", item).unwrap();
            first = false;
        }
        result
    }
"#,
                    );
                }
                "collect_vec" => {
                    code.push_str(
                        r"
    /// Collect into a Vec
    fn collect_vec(self) -> Vec<Self::Item> {
        self.collect()
    }
",
                    );
                }
                "unique" => {
                    code.push_str(
                        r"
    /// Return iterator with consecutive duplicates removed
    fn unique(self) -> std::vec::IntoIter<Self::Item>
    where
        Self::Item: PartialEq + Clone,
    {
        let mut result = Vec::new();
        for item in self {
            if !result.contains(&item) {
                result.push(item);
            }
        }
        result.into_iter()
    }
",
                    );
                }
                "intersperse" => {
                    code.push_str(
                        r"
    /// Place separator between each element
    fn intersperse(self, sep: Self::Item) -> std::vec::IntoIter<Self::Item>
    where
        Self::Item: Clone,
    {
        let mut result = Vec::new();
        let mut first = true;
        for item in self {
            if !first {
                result.push(sep.clone());
            }
            result.push(item);
            first = false;
        }
        result.into_iter()
    }
",
                    );
                }
                _ => {}
            }
        }

        // Default implementations for common methods
        if !self
            .usage
            .imported_items
            .iter()
            .any(|i| ["join", "collect_vec", "unique", "intersperse"].contains(&i.name.as_str()))
        {
            code.push_str(
                r"
    /// Collect into a Vec (convenience method)
    fn collect_vec(self) -> Vec<Self::Item> {
        self.collect()
    }
",
            );
        }

        code.push_str("}\n\n");
        code.push_str(
            r"impl<T: Iterator + Sized> AmberItertools for T {}

/// Re-export for drop-in replacement
pub use AmberItertools as Itertools;
",
        );

        code
    }

    fn replace_colored(&self) -> String {
        include_str!("template_data/colored.rs").to_string()
    }

    fn replace_anyhow(&self) -> String {
        include_str!("template_data/anyhow.rs").to_string()
    }

    fn replace_thiserror(&self) -> String {
        include_str!("template_data/thiserror.rs").to_string()
    }

    fn replace_log(&self) -> String {
        include_str!("template_data/log.rs").to_string()
    }

    fn replace_env_logger(&self) -> String {
        include_str!("template_data/env_logger.rs").to_string()
    }

    fn replace_humantime(&self) -> String {
        include_str!("template_data/humantime.rs").to_string()
    }

    fn replace_home_dirs(&self) -> String {
        include_str!("template_data/home_dirs.rs").to_string()
    }

    fn replace_either(&self) -> String {
        include_str!("template_data/either.rs").to_string()
    }

    fn replace_tap(&self) -> String {
        include_str!("template_data/tap.rs").to_string()
    }

    fn replace_cfg_if(&self) -> String {
        include_str!("template_data/cfg_if.rs").to_string()
    }

    fn replace_maplit(&self) -> String {
        include_str!("template_data/maplit.rs").to_string()
    }

    fn replace_byteorder(&self) -> String {
        include_str!("template_data/byteorder.rs").to_string()
    }

    fn replace_chrono(&self) -> String {
        include_str!("template_data/chrono.rs").to_string()
    }

    fn replace_regex(&self) -> String {
        include_str!("template_data/regex.rs").to_string()
    }

    fn generate_generic_stub(&self) -> String {
        let items: Vec<String> = self
            .usage
            .imported_items
            .iter()
            .map(|i| format!("    // TODO: Implement {}", i.name))
            .collect();

        let items_str = if items.is_empty() {
            "    // TODO: Analyze usage and implement replacement\n".to_string()
        } else {
            items.join("\n") + "\n"
        };

        format!(
            r"//! amber_{} — Replacement for the `{}` crate
//!
//! Auto-generated stub. Review and implement based on actual usage.

// Imported items detected:
{}
/// Placeholder module for {} replacement
pub mod replacements {{
    // Add your replacement implementations here
}}

/// Usage analysis:
/// - {} call sites
/// - {} unique APIs used
/// - {} affected files
/// 
/// Review the following files for usage patterns:
{}
",
            self.crate_name.replace('-', "_"),
            self.crate_name,
            items_str,
            self.crate_name,
            self.usage.call_sites.len(),
            self.usage.unique_api_usage,
            self.usage.affected_files.len(),
            self.usage
                .affected_files
                .iter()
                .map(|f| format!("///   - {f}"))
                .collect::<Vec<_>>()
                .join("\n")
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::analysis::types::{CrateUsage, ImportedItem, ItemKind, Location};

    fn usage_for(crate_name: &str) -> CrateUsage {
        CrateUsage {
            crate_name: crate_name.to_string(),
            ..Default::default()
        }
    }

    fn usage_with_items(crate_name: &str, items: &[&str]) -> CrateUsage {
        CrateUsage {
            crate_name: crate_name.to_string(),
            imported_items: items
                .iter()
                .map(|name| ImportedItem {
                    name: (*name).to_string(),
                    kind: ItemKind::Function,
                    path: format!("{crate_name}::{name}"),
                    location: Location::new("src/lib.rs", 1, 1),
                })
                .collect(),
            ..Default::default()
        }
    }

    #[test]
    fn lazy_static_template_contains_oncelock() {
        let usage = usage_for("lazy_static");
        let template = ReplacementTemplate::for_crate("lazy_static", &usage);
        let code = template.generate_code();
        assert!(code.contains("OnceLock"));
    }

    #[test]
    fn byteorder_template_has_helpers() {
        let usage = usage_for("byteorder");
        let template = ReplacementTemplate::for_crate("byteorder", &usage);
        let code = template.generate_code();
        assert!(code.contains("read_u32_le"));
        assert!(code.contains("write_u32_be"));
    }

    #[test]
    fn chrono_template_has_timestamp() {
        let usage = usage_for("chrono");
        let template = ReplacementTemplate::for_crate("chrono", &usage);
        let code = template.generate_code();
        assert!(code.contains("SystemTime"));
    }

    #[test]
    fn unknown_crate_falls_back_to_stub() {
        let usage = usage_for("unknown_crate");
        let template = ReplacementTemplate::for_crate("unknown_crate", &usage);
        let code = template.generate_code();
        assert!(code.contains("Auto-generated stub"));
    }

    #[test]
    fn all_known_templates_generate_non_empty_code() {
        let known = [
            "lazy_static",
            "once_cell",
            "itertools",
            "colored",
            "owo-colors",
            "yansi",
            "ansi_term",
            "anyhow",
            "thiserror",
            "log",
            "env_logger",
            "humantime",
            "home",
            "dirs",
            "either",
            "tap",
            "cfg-if",
            "maplit",
            "byteorder",
            "chrono",
            "regex",
        ];
        for crate_name in known {
            let usage = usage_for(crate_name);
            let template = ReplacementTemplate::for_crate(crate_name, &usage);
            let code = template.generate_code();
            assert!(!code.is_empty(), "template for {crate_name} is empty");
        }
    }

    #[test]
    fn itertools_template_includes_used_methods() {
        let usage = usage_with_items(
            "itertools",
            &["join", "collect_vec", "unique", "intersperse"],
        );
        let template = ReplacementTemplate::for_crate("itertools", &usage);
        let code = template.generate_code();
        assert!(code.contains("fn join"));
        assert!(code.contains("fn collect_vec"));
        assert!(code.contains("fn unique"));
        assert!(code.contains("fn intersperse"));
    }

    #[test]
    fn generic_stub_lists_imported_items() {
        let usage = usage_with_items("unknown", &["Foo", "Bar"]);
        let template = ReplacementTemplate::for_crate("unknown_crate", &usage);
        let code = template.generate_code();
        assert!(code.contains("TODO: Implement Foo"));
        assert!(code.contains("TODO: Implement Bar"));
    }

    #[test]
    fn generic_stub_includes_usage_summary() {
        let mut usage = usage_with_items("unknown", &["Foo"]);
        usage.call_sites.push(crate::analysis::types::CallSite {
            function_name: "foo".to_string(),
            kind: crate::analysis::types::UsageKind::FunctionCall,
            location: crate::analysis::types::Location::new("src/lib.rs", 1, 1),
            context: "fn main()".to_string(),
        });
        usage.unique_api_usage = 1;
        usage.affected_files.push("src/lib.rs".to_string());

        let template = ReplacementTemplate::for_crate("unknown_crate", &usage);
        let code = template.generate_code();
        assert!(code.contains("1 call sites"));
        assert!(code.contains("1 unique APIs used"));
        assert!(code.contains("1 affected files"));
        assert!(code.contains("src/lib.rs"));
    }

    #[test]
    fn itertools_unknown_item_adds_default_collect_vec() {
        let usage = usage_with_items("itertools", &["unknown_method"]);
        let template = ReplacementTemplate::for_crate("itertools", &usage);
        let code = template.generate_code();
        assert!(code.contains("fn collect_vec"));
    }

    #[test]
    fn itertools_no_known_items_adds_default_collect_vec() {
        let usage = usage_for("itertools");
        let template = ReplacementTemplate::for_crate("itertools", &usage);
        let code = template.generate_code();
        assert!(code.contains("fn collect_vec"));
    }
}
