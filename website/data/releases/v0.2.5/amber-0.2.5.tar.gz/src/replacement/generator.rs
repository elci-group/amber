use anyhow::{Context, Result};
use std::fs;
use std::path::PathBuf;
use tracing::info;

use crate::analysis::types::CrateUsage;
use crate::replacement::templates::ReplacementTemplate;
use crate::replacement::validator::Validator;
use crate::scoring::classifier::ReplacementScore;

/// A generated replacement proposal
#[derive(Debug, Clone)]
pub struct ReplacementProposal {
    pub original_crate: String,
    pub replacement_module: String,
    pub replacement_code: String,
    pub estimated_compile_time_reduction: String,
    pub estimated_binary_size_reduction: String,
    pub validation_strategy: Vec<String>,
    pub risk_notes: Vec<String>,
    pub test_plan: Vec<String>,
    pub validation_result: Option<String>,
}

/// Generates replacement implementations for dependencies
pub struct Generator {
    output_dir: PathBuf,
}

impl Generator {
    #[must_use]
    pub const fn new(output_dir: PathBuf) -> Self {
        Self { output_dir }
    }

    /// Generate a replacement proposal for a dependency.
    ///
    /// # Errors
    ///
    /// Returns an error if the replacement module cannot be written to disk.
    pub fn generate_replacement(
        &self,
        crate_name: &str,
        usage: &CrateUsage,
        score: &ReplacementScore,
    ) -> Result<ReplacementProposal> {
        info!(
            "Generating replacement for {} (score: {})",
            crate_name, score.overall
        );

        let template = ReplacementTemplate::for_crate(crate_name, usage);
        let replacement_code = template.generate_code();
        let replacement_module = format!("amber_{}", crate_name.replace('-', "_"));

        // Write the replacement module to disk
        let module_path = self.output_dir.join(format!("{replacement_module}.rs"));
        fs::create_dir_all(&self.output_dir)?;
        fs::write(&module_path, &replacement_code)
            .with_context(|| format!("Failed to write replacement to {}", module_path.display()))?;

        info!("Wrote replacement module to {}", module_path.display());

        let validation_result =
            match Validator::new().validate(&replacement_module, &replacement_code) {
                Ok(()) => Some("cargo check passed".to_string()),
                Err(e) => Some(format!("cargo check failed: {e}")),
            };

        Ok(ReplacementProposal {
            original_crate: crate_name.to_string(),
            replacement_module,
            replacement_code,
            estimated_compile_time_reduction: Self::estimate_compile_reduction(crate_name),
            estimated_binary_size_reduction: Self::estimate_binary_reduction(crate_name),
            validation_strategy: Self::build_validation_strategy(crate_name, usage),
            risk_notes: score.reasoning.clone(),
            test_plan: Self::build_test_plan(crate_name, usage),
            validation_result,
        })
    }

    fn estimate_compile_reduction(crate_name: &str) -> String {
        // Rough estimates based on known compile times
        let reduction = match crate_name {
            "syn" => "-15-25%",
            "regex" => "-5-10%",
            "chrono" | "rand" => "-3-8%",
            "serde" | "clap" => "-5-15%",
            "reqwest" | "tokio" => "-10-20%",
            "lazy_static" | "once_cell" | "log" | "env_logger" => "-1-3%",
            "itertools" | "anyhow" | "thiserror" | "uuid" => "-2-5%",
            "colored" | "owo-colors" => "-1-2%",
            _ => "-2-10% (estimated)",
        };
        reduction.to_string()
    }

    fn estimate_binary_reduction(crate_name: &str) -> String {
        let reduction = match crate_name {
            "syn" => "-500KB-1.5MB",
            "regex" => "-200KB-500KB",
            "chrono" | "rand" => "-100KB-300KB",
            "serde" => "-200KB-800KB",
            "reqwest" => "-500KB-2MB",
            "tokio" => "-300KB-1MB",
            "clap" => "-100KB-500KB",
            "lazy_static" | "once_cell" => "-10KB-50KB",
            "itertools" => "-50KB-150KB",
            "colored" | "owo-colors" => "-10KB-30KB",
            "anyhow" | "thiserror" => "-30KB-100KB",
            "uuid" => "-50KB-200KB",
            "log" | "env_logger" => "-20KB-80KB",
            _ => "-50KB-500KB (estimated)",
        };
        reduction.to_string()
    }

    fn build_validation_strategy(_crate_name: &str, usage: &CrateUsage) -> Vec<String> {
        let mut strategies = vec![
            "Run existing test suite".to_string(),
            "Verify no compilation errors".to_string(),
        ];

        if usage.affected_files.len() > 5 {
            strategies.push("Integration testing across all affected modules".to_string());
        }

        if !usage.is_trivial_usage {
            strategies.push("Property-based testing for edge cases".to_string());
            strategies.push("Differential testing against original implementation".to_string());
        }

        if usage.used_in_public_api {
            strategies.push("Check downstream API compatibility".to_string());
        }

        strategies.push("Benchmark comparison (before/after)".to_string());

        strategies
    }

    fn build_test_plan(crate_name: &str, usage: &CrateUsage) -> Vec<String> {
        let mut tests = vec![format!(
            "Test all {} call sites of {}",
            usage.call_sites.len(),
            crate_name
        )];

        for item in &usage.imported_items {
            tests.push(format!(
                "Verify {}::{} behavior matches original",
                crate_name, item.name
            ));
        }

        tests.push("Performance regression test".to_string());
        tests.push("Memory usage comparison".to_string());
        tests.push("Compile time check".to_string());

        tests
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scoring::classifier::{
        ReplacementRecommendation, ReplacementScore, SafetyClass, ScoreDimensions,
    };

    fn dummy_score() -> ReplacementScore {
        ReplacementScore {
            overall: 80,
            confidence: 90,
            classification: SafetyClass::SafeToReplace,
            dimensions: ScoreDimensions::default(),
            reasoning: vec!["test reason".to_string()],
            recommendation: ReplacementRecommendation::Proceed,
        }
    }

    #[test]
    fn generates_replacement_file_and_proposal() {
        let temp = tempfile::tempdir().unwrap();
        let generator = Generator::new(temp.path().to_path_buf());
        let usage = CrateUsage::default();
        let score = dummy_score();

        let proposal = generator
            .generate_replacement("anyhow", &usage, &score)
            .expect("generate replacement");

        assert!(temp
            .path()
            .join(&proposal.replacement_module)
            .with_extension("rs")
            .exists());
        assert_eq!(proposal.original_crate, "anyhow");
        assert!(!proposal.replacement_code.is_empty());
        assert!(proposal.validation_result.is_some());
    }

    #[test]
    fn estimates_for_known_crates_are_consistent() {
        let temp = tempfile::tempdir().unwrap();
        let generator = Generator::new(temp.path().to_path_buf());
        for crate_name in [
            "syn",
            "regex",
            "tokio",
            "lazy_static",
            "colored",
            "owo-colors",
            "uuid",
            "log",
            "env_logger",
        ] {
            let proposal = generator
                .generate_replacement(crate_name, &CrateUsage::default(), &dummy_score())
                .unwrap();
            assert!(!proposal.estimated_compile_time_reduction.is_empty());
            assert!(!proposal.estimated_binary_size_reduction.is_empty());
        }
    }

    #[test]
    fn nontrivial_usage_adds_validation_steps() {
        let temp = tempfile::tempdir().unwrap();
        let generator = Generator::new(temp.path().to_path_buf());
        let usage = CrateUsage {
            affected_files: vec!["a", "b", "c", "d", "e", "f"]
                .into_iter()
                .map(String::from)
                .collect(),
            used_in_public_api: true,
            is_trivial_usage: false,
            ..Default::default()
        };
        let proposal = generator
            .generate_replacement("anyhow", &usage, &dummy_score())
            .unwrap();
        assert!(proposal
            .validation_strategy
            .iter()
            .any(|s| s.contains("Integration testing")));
        assert!(proposal
            .validation_strategy
            .iter()
            .any(|s| s.contains("downstream API compatibility")));
    }
}
