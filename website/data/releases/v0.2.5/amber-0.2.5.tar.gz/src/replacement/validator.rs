use anyhow::{Context, Result};
use std::fs;
use std::process::Command;
use tempfile::TempDir;
use tracing::{debug, info};

/// Validates that a generated replacement module compiles.
pub struct Validator;

impl Validator {
    /// Create a new validator.
    #[must_use]
    pub const fn new() -> Self {
        Self
    }

    /// Validate that `replacement_code` compiles as a standalone Rust module.
    ///
    /// A temporary Cargo project is created, the code is written as a module,
    /// and `cargo check` is run. This does not prove the replacement is
    /// behaviorally equivalent to the original crate, only that it is valid
    /// Rust.
    ///
    /// # Errors
    ///
    /// Returns an error if the temporary project cannot be created, the module
    /// cannot be written, or `cargo check` fails.
    pub fn validate(&self, module_name: &str, replacement_code: &str) -> Result<()> {
        info!("Validating replacement module: {}", module_name);

        let temp = TempDir::new().context("failed to create temporary directory")?;
        let project_dir = temp.path();

        Self::write_cargo_toml(project_dir, module_name)?;
        Self::write_module(project_dir, module_name, replacement_code)?;

        debug!("Running cargo check in {}", project_dir.display());
        let output = Command::new("cargo")
            .arg("check")
            .current_dir(project_dir)
            .output()
            .context("failed to run cargo check")?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            anyhow::bail!("replacement module failed cargo check:\n{stderr}");
        }

        info!("Replacement module {} passed cargo check", module_name);
        Ok(())
    }

    fn write_cargo_toml(project_dir: &std::path::Path, module_name: &str) -> Result<()> {
        let cargo_toml = format!(
            r#"[package]
name = "{module_name}"
version = "0.1.0"
edition = "2021"
"#
        );
        fs::write(project_dir.join("Cargo.toml"), cargo_toml)?;
        Ok(())
    }

    fn write_module(
        project_dir: &std::path::Path,
        module_name: &str,
        replacement_code: &str,
    ) -> Result<()> {
        let src_dir = project_dir.join("src");
        fs::create_dir_all(&src_dir)?;

        let module_file = format!("{module_name}.rs");
        fs::write(src_dir.join(&module_file), replacement_code)?;

        let lib_rs = format!(
            r"mod {module_name};
pub use {module_name}::*;
"
        );
        fs::write(src_dir.join("lib.rs"), lib_rs)?;
        Ok(())
    }
}

impl Default for Validator {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_module_passes_cargo_check() {
        let validator = Validator::new();
        let code = r"pub fn answer() -> i32 { 42 }";
        assert!(validator.validate("valid_mod", code).is_ok());
    }

    #[test]
    fn invalid_module_fails_cargo_check() {
        let validator = Validator::new();
        let code = r"pub fn broken( { }";
        assert!(validator.validate("invalid_mod", code).is_err());
    }

    #[test]
    #[allow(clippy::default_constructed_unit_structs)]
    fn default_matches_new() {
        assert_eq!(
            Validator::default()
                .validate("valid_mod", "pub fn x() {}")
                .is_ok(),
            Validator::new()
                .validate("valid_mod", "pub fn x() {}")
                .is_ok()
        );
    }
}
