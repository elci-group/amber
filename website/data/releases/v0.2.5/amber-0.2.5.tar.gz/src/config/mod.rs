//! Configuration and policy enforcement.
//!
//! Amber can read a `.amber.toml` file from the target project directory to
//! customize scoring weights, thresholds, and policies.

use serde::{Deserialize, Serialize};
use std::collections::HashSet;

/// Top-level configuration file.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Config {
    /// Minimum score threshold for replacement proposals.
    pub threshold: Option<u8>,
    /// Per-dimension scoring weights.
    pub weights: Option<Weights>,
    /// Policy enforcement.
    pub policy: Option<Policy>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Weights {
    pub usage_simplicity: f64,
    pub transitive_value: f64,
    pub security_safety: f64,
    pub maintenance_burden: f64,
    pub testability: f64,
    pub api_surface: f64,
}

impl Default for Weights {
    fn default() -> Self {
        Self {
            usage_simplicity: 0.25,
            transitive_value: 0.20,
            security_safety: 0.25,
            maintenance_burden: 0.10,
            testability: 0.10,
            api_surface: 0.10,
        }
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Policy {
    /// Crates that must remain in the project.
    pub required: Vec<String>,
    /// Crates that must never be introduced.
    pub forbidden: Vec<String>,
    /// Treat policy violations as errors.
    #[serde(default)]
    pub strict: bool,
}

impl Policy {
    /// Check if a crate is required.
    #[must_use]
    pub fn is_required(&self, name: &str) -> bool {
        self.required.iter().any(|r| r == name)
    }

    /// Check if a crate is forbidden.
    #[must_use]
    pub fn is_forbidden(&self, name: &str) -> bool {
        self.forbidden.iter().any(|f| f == name)
    }

    /// Validate a set of dependency names against the policy.
    #[must_use]
    pub fn validate(&self, deps: &HashSet<String>) -> Vec<PolicyViolation> {
        let mut violations = Vec::new();

        for required in &self.required {
            if !deps.contains(required) {
                violations.push(PolicyViolation::MissingRequired(required.clone()));
            }
        }

        for dep in deps {
            if self.is_forbidden(dep) {
                violations.push(PolicyViolation::Forbidden(dep.clone()));
            }
        }

        violations
    }
}

/// A policy violation detected during analysis.
#[derive(Debug, Clone)]
pub enum PolicyViolation {
    MissingRequired(String),
    Forbidden(String),
}

impl PolicyViolation {
    /// Human-readable description of the violation.
    #[must_use]
    pub fn message(&self) -> String {
        match self {
            Self::MissingRequired(name) => {
                format!("Required dependency '{name}' is missing")
            }
            Self::Forbidden(name) => {
                format!("Forbidden dependency '{name}' is present")
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn policy_detects_missing_required() {
        let policy = Policy {
            required: vec!["serde".to_string()],
            forbidden: Vec::new(),
            strict: false,
        };
        let deps: HashSet<String> = std::iter::once("anyhow".to_string()).collect();
        let violations = policy.validate(&deps);
        assert_eq!(violations.len(), 1);
        assert!(matches!(
            &violations[0],
            PolicyViolation::MissingRequired(name) if name == "serde"
        ));
    }

    #[test]
    fn policy_detects_forbidden() {
        let policy = Policy {
            required: Vec::new(),
            forbidden: vec!["deprecated_crate".to_string()],
            strict: false,
        };
        let deps: HashSet<String> = ["anyhow".to_string(), "deprecated_crate".to_string()]
            .into_iter()
            .collect();
        let violations = policy.validate(&deps);
        assert_eq!(violations.len(), 1);
        assert!(matches!(
            &violations[0],
            PolicyViolation::Forbidden(name) if name == "deprecated_crate"
        ));
    }

    #[test]
    fn policy_passes_when_clean() {
        let policy = Policy {
            required: vec!["serde".to_string()],
            forbidden: vec!["deprecated_crate".to_string()],
            strict: false,
        };
        let deps: HashSet<String> = ["serde".to_string(), "anyhow".to_string()]
            .into_iter()
            .collect();
        assert!(policy.validate(&deps).is_empty());
    }

    #[test]
    fn policy_violation_messages_are_descriptive() {
        let missing = PolicyViolation::MissingRequired("serde".to_string());
        assert!(missing.message().contains("Required dependency"));

        let forbidden = PolicyViolation::Forbidden("bad".to_string());
        assert!(forbidden.message().contains("Forbidden dependency"));
    }

    #[test]
    fn default_weights_sum_to_one() {
        let weights = Weights::default();
        let sum = weights.usage_simplicity
            + weights.transitive_value
            + weights.security_safety
            + weights.maintenance_burden
            + weights.testability
            + weights.api_surface;
        assert!((sum - 1.0).abs() < f64::EPSILON);
    }

    #[test]
    fn policy_required_and_forbidden_checks_match() {
        let policy = Policy {
            required: vec!["serde".to_string()],
            forbidden: vec!["bad".to_string()],
            strict: false,
        };
        assert!(policy.is_required("serde"));
        assert!(!policy.is_required("other"));
        assert!(policy.is_forbidden("bad"));
        assert!(!policy.is_forbidden("other"));
    }
}
