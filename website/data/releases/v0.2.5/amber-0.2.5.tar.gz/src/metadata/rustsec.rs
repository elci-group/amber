//! `RustSec` advisory database integration.
//!
//! Loads (or updates) the `RustSec` advisory database from a local cache
//! directory and counts matching advisories per crate. The database is
//! fetched with the `git` CLI when it is missing or stale.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::OnceLock;

use rustsec::database::Database;
use tracing::{debug, warn};

use super::{CrateMetadata, MetadataProvider};
use crate::analysis::types::Dependency;

const RUSTSEC_DB_URL: &str = "https://github.com/RustSec/advisory-db.git";
const DEFAULT_CACHE_DIR: &str = ".amber/rustsec-advisory-db";

type GitRunner = Box<dyn Fn(&Path, &[&str]) -> Result<(), RustSecError> + Send + Sync>;

/// Source of `RustSec` security advisories backed by a local git cache.
pub struct RustSecSource {
    cache_dir: PathBuf,
    db: OnceLock<Option<Database>>,
    git_runner: GitRunner,
}

impl RustSecSource {
    /// Create a new source using the default cache directory under the
    /// current working directory.
    #[must_use]
    pub fn new() -> Self {
        Self::with_cache_dir(DEFAULT_CACHE_DIR)
    }

    /// Create a new source using the provided cache directory.
    #[must_use]
    pub fn with_cache_dir(cache_dir: impl Into<PathBuf>) -> Self {
        Self {
            cache_dir: cache_dir.into(),
            db: OnceLock::new(),
            git_runner: Box::new(Self::run_git),
        }
    }

    #[cfg(test)]
    fn with_git_runner(cache_dir: impl Into<PathBuf>, git_runner: GitRunner) -> Self {
        Self {
            cache_dir: cache_dir.into(),
            db: OnceLock::new(),
            git_runner,
        }
    }

    /// Return the number of non-withdrawn advisories affecting `crate_name`.
    pub fn advisory_count(&self, crate_name: &str) -> usize {
        self.database()
            .map_or(0, |db| Self::count_advisories(db, crate_name))
    }

    fn database(&self) -> Option<&Database> {
        self.db
            .get_or_init(|| {
                if let Err(e) = self.ensure_database() {
                    warn!("RustSec advisory database unavailable: {e}");
                    return None;
                }
                match Database::open(&self.cache_dir) {
                    Ok(db) => Some(db),
                    Err(e) => {
                        warn!("Failed to open RustSec database: {e}");
                        None
                    }
                }
            })
            .as_ref()
    }

    fn count_advisories(db: &Database, crate_name: &str) -> usize {
        db.iter()
            .filter(|advisory| {
                !advisory.withdrawn() && advisory.metadata.package.as_str() == crate_name
            })
            .count()
    }

    fn ensure_database(&self) -> Result<(), RustSecError> {
        let crates_dir = self.cache_dir.join("crates");
        if crates_dir.is_dir() {
            debug!(
                "Updating RustSec advisory database in {}",
                self.cache_dir.display()
            );
            (self.git_runner)(&self.cache_dir, &["pull", "--ff-only", "--depth", "1"])
        } else {
            debug!(
                "Cloning RustSec advisory database to {}",
                self.cache_dir.display()
            );
            std::fs::create_dir_all(&self.cache_dir)?;
            let parent = self.cache_dir.parent().unwrap_or(&self.cache_dir);
            (self.git_runner)(
                parent,
                &[
                    "clone",
                    "--depth",
                    "1",
                    RUSTSEC_DB_URL,
                    &self.cache_dir.to_string_lossy(),
                ],
            )
        }
    }

    fn run_git(cwd: &Path, args: &[&str]) -> Result<(), RustSecError> {
        let output = Command::new("git")
            .args(args)
            .current_dir(cwd)
            .output()
            .map_err(|e| RustSecError::Git(format!("failed to run git: {e}")))?;

        if output.status.success() {
            Ok(())
        } else {
            let stderr = String::from_utf8_lossy(&output.stderr);
            Err(RustSecError::Git(format!("git exited with {stderr}")))
        }
    }
}

impl Default for RustSecSource {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug)]
enum RustSecError {
    Io(std::io::Error),
    Git(String),
}

impl std::fmt::Display for RustSecError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(e) => write!(f, "{e}"),
            Self::Git(msg) => write!(f, "{msg}"),
        }
    }
}

impl std::error::Error for RustSecError {}

impl From<std::io::Error> for RustSecError {
    fn from(e: std::io::Error) -> Self {
        Self::Io(e)
    }
}

/// Wraps another metadata provider and enriches CVE counts from `RustSec`.
pub struct RustSecEnricher<P> {
    inner: P,
    source: RustSecSource,
}

impl<P> RustSecEnricher<P> {
    /// Create a new enricher around `inner`.
    #[must_use]
    pub fn new(inner: P) -> Self {
        Self {
            inner,
            source: RustSecSource::new(),
        }
    }

    #[cfg(test)]
    const fn with_source(inner: P, source: RustSecSource) -> Self {
        Self { inner, source }
    }
}

impl<P: MetadataProvider> MetadataProvider for RustSecEnricher<P> {
    fn fetch(&self, dep: &Dependency) -> CrateMetadata {
        let mut meta = self.inner.fetch(dep);
        meta.cve_count = self.source.advisory_count(&dep.name);
        meta
    }

    fn fetch_batch(&self, deps: &[Dependency]) -> Vec<CrateMetadata> {
        let mut results = self.inner.fetch_batch(deps);

        if let Some(db) = self.source.database() {
            let counts: HashMap<String, usize> = deps
                .iter()
                .map(|dep| {
                    (
                        dep.name.clone(),
                        RustSecSource::count_advisories(db, &dep.name),
                    )
                })
                .collect();

            for (meta, dep) in results.iter_mut().zip(deps.iter()) {
                meta.cve_count = *counts.get(&dep.name).unwrap_or(&0);
            }
        }

        results
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::analysis::types::{Dependency, DependencyKind, DependencySource};

    #[test]
    fn default_source_matches_new() {
        let a = RustSecSource::default();
        let b = RustSecSource::new();
        assert_eq!(a.cache_dir, b.cache_dir);
    }

    #[test]
    fn rustsec_error_display_formats() {
        let io_err = RustSecError::Io(std::io::Error::new(std::io::ErrorKind::NotFound, "missing"));
        assert!(io_err.to_string().contains("missing"));

        let git_err = RustSecError::Git("clone failed".to_string());
        assert_eq!(git_err.to_string(), "clone failed");
    }

    #[test]
    fn rustsec_error_from_io() {
        let io = std::io::Error::other("oops");
        let err: RustSecError = io.into();
        assert!(err.to_string().contains("oops"));
    }

    #[test]
    fn git_failure_returns_zero_advisories() {
        let temp = tempfile::tempdir().unwrap();
        let source = RustSecSource::with_git_runner(
            temp.path().join("db"),
            Box::new(|_cwd, _args| Err(RustSecError::Git("no git".to_string()))),
        );
        assert_eq!(source.advisory_count("serde"), 0);
    }

    #[test]
    fn clone_success_but_invalid_db_returns_zero() {
        let temp = tempfile::tempdir().unwrap();
        let db_dir = temp.path().join("db");
        let source = RustSecSource::with_git_runner(
            db_dir.clone(),
            Box::new(move |_cwd, _args| {
                // Create a crates dir so ensure_database takes the update path next time,
                // but leave the DB invalid so Database::open fails.
                std::fs::create_dir_all(db_dir.join("crates")).unwrap();
                Ok(())
            }),
        );
        assert_eq!(source.advisory_count("serde"), 0);
    }

    #[test]
    fn enricher_propagates_default_cve_count() {
        struct MockProvider;
        impl MetadataProvider for MockProvider {
            fn fetch(&self, _dep: &Dependency) -> CrateMetadata {
                CrateMetadata::default()
            }
        }

        let temp = tempfile::tempdir().unwrap();
        let source = RustSecSource::with_git_runner(
            temp.path().join("db"),
            Box::new(|_cwd, _args| Err(RustSecError::Git("no git".to_string()))),
        );
        let enricher = RustSecEnricher::with_source(MockProvider, source);
        let dep = Dependency {
            name: "serde".to_string(),
            version: "1.0.0".to_string(),
            source: DependencySource::CratesIo,
            kind: DependencyKind::Normal,
            features: Vec::new(),
            optional: false,
            uses_default_features: true,
            transitive_deps: Vec::new(),
            loc_approx: 0,
            public_api_count: 0,
            last_release: None,
            maintenance_score: 0,
            cve_count: 0,
            license: None,
            download_count: 0,
        };
        let meta = enricher.fetch(&dep);
        assert_eq!(meta.cve_count, 0);
    }

    fn write_minimal_advisory(db_dir: &std::path::Path, crate_name: &str, id: &str) {
        let crate_dir = db_dir.join("crates").join(crate_name);
        std::fs::create_dir_all(&crate_dir).unwrap();
        std::fs::write(
            crate_dir.join(format!("{id}.md")),
            format!(
                r#"```toml
[advisory]
id = "{id}"
package = "{crate_name}"
date = "2021-01-01"
url = "https://example.com"
categories = ["code-execution"]

[versions]
patched = [">= 1.0.0"]
```

# Test advisory for {crate_name}

Description goes here.
"#
            ),
        )
        .unwrap();
    }

    #[test]
    fn advisory_count_uses_open_database() {
        let temp = tempfile::tempdir().unwrap();
        let db_dir = temp.path().join("db");
        write_minimal_advisory(&db_dir, "vulnerable", "RUSTSEC-2021-0001");

        // Verify the database loads before wrapping it in the source.
        let db = Database::open(&db_dir).expect("open test database");
        assert_eq!(db.iter().count(), 1, "expected one advisory in test db");

        // Pre-seed the DB so ensure_database takes the update path.
        let source = RustSecSource::with_git_runner(
            db_dir.clone(),
            Box::new(move |_cwd, _args| {
                assert!(db_dir.join("crates").is_dir());
                Ok(())
            }),
        );
        assert_eq!(source.advisory_count("vulnerable"), 1);
        assert_eq!(source.advisory_count("safe"), 0);
    }

    #[test]
    fn fetch_batch_enriches_cve_counts() {
        struct MockProvider;
        impl MetadataProvider for MockProvider {
            fn fetch(&self, _dep: &Dependency) -> CrateMetadata {
                CrateMetadata::default()
            }

            fn fetch_batch(&self, deps: &[Dependency]) -> Vec<CrateMetadata> {
                deps.iter().map(|_| CrateMetadata::default()).collect()
            }
        }

        let temp = tempfile::tempdir().unwrap();
        let db_dir = temp.path().join("db");
        write_minimal_advisory(&db_dir, "vulnerable", "RUSTSEC-2021-0001");

        let source = RustSecSource::with_git_runner(db_dir, Box::new(move |_cwd, _args| Ok(())));
        let enricher = RustSecEnricher::with_source(MockProvider, source);
        let deps = vec![
            Dependency {
                name: "vulnerable".to_string(),
                version: "1.0.0".to_string(),
                source: DependencySource::CratesIo,
                kind: DependencyKind::Normal,
                features: Vec::new(),
                optional: false,
                uses_default_features: true,
                transitive_deps: Vec::new(),
                loc_approx: 0,
                public_api_count: 0,
                last_release: None,
                maintenance_score: 0,
                cve_count: 0,
                license: None,
                download_count: 0,
            },
            Dependency {
                name: "safe".to_string(),
                version: "1.0.0".to_string(),
                source: DependencySource::CratesIo,
                kind: DependencyKind::Normal,
                features: Vec::new(),
                optional: false,
                uses_default_features: true,
                transitive_deps: Vec::new(),
                loc_approx: 0,
                public_api_count: 0,
                last_release: None,
                maintenance_score: 0,
                cve_count: 0,
                license: None,
                download_count: 0,
            },
        ];
        let results = enricher.fetch_batch(&deps);
        assert_eq!(results[0].cve_count, 1);
        assert_eq!(results[1].cve_count, 0);
    }
}
