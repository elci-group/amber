//! Amber — Autonomous Dependency Reduction Engine
//!
//! Scans Rust projects, analyzes dependency usage, scores replaceability,
//! and generates replacement proposals with automated validation.

#![warn(clippy::pedantic, clippy::nursery)]

use amber::analysis::repo::RepositoryAnalyzer;
use amber::analysis::usage::UsageAnalyzer;
use amber::config::Config;
use amber::replacement::Generator;
use amber::reporting::formatters::{ConsoleReporter, EmojiReporter, JsonReporter, PrReporter};
use amber::scoring::classifier::SafetyClassifier;
use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use colored::Colorize;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use tracing::{info, warn};

/// Amber: Autonomous Dependency Reduction Engine
#[derive(Parser, Debug)]
#[command(name = "amber")]
#[command(about = "Dependency garbage collector for Rust")]
#[command(version = env!("CARGO_PKG_VERSION"))]
#[allow(clippy::struct_excessive_bools)]
struct Cli {
    /// Path to the Rust project to analyze
    #[arg(default_value = ".")]
    path: PathBuf,

    /// Output format
    #[arg(short, long, value_enum, default_value = "console")]
    format: OutputFormat,

    /// Minimum safety score threshold (0-100)
    #[arg(short, long, default_value = "50")]
    threshold: u8,

    /// Show transitive dependencies
    #[arg(short = 'T', long)]
    transitive: bool,

    /// Generate replacement proposals
    #[arg(short, long)]
    propose: bool,

    /// Exclude dev-dependencies from analysis
    #[arg(long)]
    no_dev: bool,

    /// Focus on specific crates (comma-separated)
    #[arg(short, long, value_delimiter = ',')]
    crates: Vec<String>,

    /// Verbosity level
    #[arg(short, long, action = clap::ArgAction::Count)]
    verbose: u8,

    /// Path to .amber.toml config file
    #[arg(long)]
    config: Option<PathBuf>,

    /// Fetch live metadata from crates.io (requires `online` feature)
    #[cfg(feature = "online")]
    #[arg(long)]
    online: bool,

    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Clone, Debug, Default, clap::ValueEnum)]
enum OutputFormat {
    #[default]
    Console,
    Json,
    Pr,
    Sarif,
    Emoji,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Analyze dependencies and generate report
    Analyze {
        /// Export report to file
        #[arg(short, long)]
        output: Option<PathBuf>,
    },
    /// Score a specific dependency's replaceability
    Score {
        /// Crate name to score
        crate_name: String,
    },
    /// List all dependencies with usage statistics
    List,
    /// Generate replacement code for a dependency
    Replace {
        /// Crate to replace
        crate_name: String,
        /// Output directory for generated code
        #[arg(short, long, default_value = "amber_out")]
        out_dir: PathBuf,
    },
    /// Show Amber's internal module roadmap
    Roadmap,
}

const fn use_online(cli: &Cli) -> bool {
    #[cfg(feature = "online")]
    return cli.online;
    #[cfg(not(feature = "online"))]
    {
        let _ = cli;
        false
    }
}

fn load_config(cli: &Cli, manifest_path: &Path) -> Result<Config> {
    let config_path = cli.config.as_ref().map_or_else(
        || {
            manifest_path
                .parent()
                .unwrap_or_else(|| Path::new("."))
                .join(".amber.toml")
        },
        std::clone::Clone::clone,
    );

    if config_path.exists() {
        let content = std::fs::read_to_string(&config_path)
            .with_context(|| format!("Failed to read config from {}", config_path.display()))?;
        toml::from_str(&content)
            .with_context(|| format!("Failed to parse config from {}", config_path.display()))
    } else {
        Ok(Config::default())
    }
}

fn build_analyzer(manifest_path: &Path, cli: &Cli) -> Result<RepositoryAnalyzer> {
    use amber::metadata::offline::OfflineProvider;
    use amber::metadata::rustsec::RustSecEnricher;

    #[cfg(feature = "online")]
    use amber::metadata::online::CratesIoProvider;

    if use_online(cli) {
        #[cfg(feature = "online")]
        {
            info!("Using online metadata provider (crates.io)");
            return RepositoryAnalyzer::with_provider(
                manifest_path,
                Box::new(RustSecEnricher::new(CratesIoProvider::new())),
            );
        }
        #[cfg(not(feature = "online"))]
        {
            anyhow::bail!("The --online flag requires the `online` Cargo feature");
        }
    }

    info!("Using offline metadata provider with RustSec enrichment");
    RepositoryAnalyzer::with_provider(
        manifest_path,
        Box::new(RustSecEnricher::new(OfflineProvider::new())),
    )
}

fn main() {
    let cli = Cli::parse();
    let exit_code = match execute(&cli) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("{} {e}", "error:".red().bold());
            1
        }
    };
    std::process::exit(exit_code);
}

fn execute(cli: &Cli) -> Result<i32> {
    // Initialize tracing
    let filter = match cli.verbose {
        0 => "amber=info",
        1 => "amber=debug",
        _ => "amber=trace",
    };
    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new(filter)),
        )
        .without_time()
        .try_init();

    print_banner();

    let manifest_path = if cli.path.join("Cargo.toml").exists() {
        cli.path.join("Cargo.toml")
    } else {
        cli.path.clone()
    };

    run(cli, &manifest_path)
}

pub(crate) fn run(cli: &Cli, manifest_path: &Path) -> Result<i32> {
    match &cli.command {
        Some(Commands::Roadmap) => {
            print_roadmap();
            return Ok(0);
        }
        Some(Commands::List) => {
            info!("Listing all dependencies...");
            let analyzer = build_analyzer(manifest_path, cli)?;
            let deps = analyzer.list_dependencies(cli.transitive, !cli.no_dev)?;
            if matches!(cli.format, OutputFormat::Emoji) {
                EmojiReporter::new().print_dependency_list(&deps);
            } else {
                ConsoleReporter::new().print_dependency_list(&deps);
            }
        }
        Some(Commands::Score { crate_name }) => {
            info!("Scoring dependency: {crate_name}");
            let analyzer = build_analyzer(manifest_path, cli)?;
            let dep = analyzer.get_dependency(crate_name)?;
            let usage = UsageAnalyzer::new(manifest_path)?;
            let usage_stats = usage.analyze_crate_usage(crate_name)?;
            let classifier = SafetyClassifier::new();
            let score = classifier.score_dependency(&dep, &usage_stats);
            if matches!(cli.format, OutputFormat::Emoji) {
                EmojiReporter::new().print_score_card(crate_name, &score, &usage_stats);
            } else {
                ConsoleReporter::new().print_score_card(crate_name, &score, &usage_stats);
            }
        }
        Some(Commands::Replace {
            crate_name,
            out_dir,
        }) => {
            info!("Generating replacement for: {crate_name}");
            let analyzer = build_analyzer(manifest_path, cli)?;
            let dep = analyzer.get_dependency(crate_name)?;
            let usage = UsageAnalyzer::new(manifest_path)?;
            let usage_stats = usage.analyze_crate_usage(crate_name)?;
            let classifier = SafetyClassifier::new();
            let score = classifier.score_dependency(&dep, &usage_stats);

            if score.overall < cli.threshold {
                warn!(
                    "Score ({}) below threshold ({}). Use --threshold to override.",
                    score.overall, cli.threshold
                );
                return Ok(0);
            }

            let generator = Generator::new(out_dir.clone());
            let proposal = generator.generate_replacement(crate_name, &usage_stats, &score)?;
            let reporter = ConsoleReporter::new();
            reporter.print_replacement_proposal(&proposal);
        }
        Some(Commands::Analyze { output }) => {
            info!("Starting full repository analysis...");
            let code = run_full_analysis(cli, manifest_path, output.as_deref())?;
            return Ok(code);
        }
        None => {
            info!("Starting full repository analysis...");
            let code = run_full_analysis(cli, manifest_path, None)?;
            return Ok(code);
        }
    }

    Ok(0)
}

#[allow(clippy::too_many_lines)]
fn run_full_analysis(cli: &Cli, manifest_path: &Path, output_path: Option<&Path>) -> Result<i32> {
    let config = load_config(cli, manifest_path)?;
    let threshold = config.threshold.unwrap_or(cli.threshold);

    // Phase 1: Repository Analysis
    info!("Phase 1: Indexing repository dependencies...");
    let analyzer = build_analyzer(manifest_path, cli)?;
    let deps = analyzer.list_dependencies(cli.transitive, !cli.no_dev)?;

    if deps.is_empty() {
        println!(
            "{}",
            "No dependencies found. Is this a Rust project?".yellow()
        );
        return Ok(0);
    }

    println!(
        "  {} {} dependencies indexed",
        "✓".green(),
        deps.len().to_string().bold()
    );

    // Phase 2: Usage Analysis
    info!("Phase 2: Analyzing contextual usage...");
    let usage_analyzer = UsageAnalyzer::new(manifest_path)?;
    let usage_stats = usage_analyzer.analyze_all_usage(&deps)?;
    println!(
        "  {} Usage patterns extracted for {} crates",
        "✓".green(),
        usage_stats.len().to_string().bold()
    );

    // Phase 3: Safety Classification
    info!("Phase 3: Classifying replacement safety...");
    let classifier = SafetyClassifier::new();
    let scores: Vec<_> = deps
        .iter()
        .map(|dep| {
            let usage = usage_stats.get(&dep.name).cloned().unwrap_or_default();
            classifier.score_dependency(dep, &usage)
        })
        .collect();
    println!("  {} Safety scores computed", "✓".green());

    // Phase 4: Generate report
    info!("Phase 4: Generating report...");
    match cli.format {
        OutputFormat::Console => {
            let reporter = ConsoleReporter::new();
            reporter.print_full_report(&deps, &usage_stats, &scores, threshold);
        }
        OutputFormat::Json => {
            let reporter = JsonReporter::new();
            let json = reporter.generate_json(&deps, &usage_stats, &scores)?;
            if let Some(path) = output_path {
                std::fs::write(path, json)?;
                println!("\n{} Report written to {}", "✓".green(), path.display());
            } else {
                println!("{json}");
            }
        }
        OutputFormat::Pr => {
            let reporter = PrReporter::new();
            let pr_body = reporter.generate_pr_body(&deps, &usage_stats, &scores, threshold);
            if let Some(path) = output_path {
                std::fs::write(path, pr_body)?;
                println!(
                    "\n{} PR description written to {}",
                    "✓".green(),
                    path.display()
                );
            } else {
                println!("{pr_body}");
            }
        }
        OutputFormat::Sarif => {
            let reporter = amber::reporting::formatters::SarifReporter::new();
            let sarif = reporter.generate_sarif(&deps, &usage_stats, &scores)?;
            if let Some(path) = output_path {
                std::fs::write(path, sarif)?;
                println!(
                    "\n{} SARIF report written to {}",
                    "✓".green(),
                    path.display()
                );
            } else {
                println!("{sarif}");
            }
        }
        OutputFormat::Emoji => {
            let reporter = EmojiReporter::new();
            reporter.print_full_report(&deps, &usage_stats, &scores, threshold);
        }
    }

    // Phase 5: Replacement proposals (if requested)
    if cli.propose {
        info!("Phase 5: Generating replacement proposals...");
        let generator = Generator::new(PathBuf::from("amber_proposals"));
        for (dep, score) in deps.iter().zip(scores.iter()) {
            if score.overall >= threshold {
                let usage = usage_stats.get(&dep.name).cloned().unwrap_or_default();
                if let Err(e) = generator.generate_replacement(&dep.name, &usage, score) {
                    warn!("Failed to generate replacement for {}: {}", dep.name, e);
                }
            }
        }
        println!(
            "  {} Replacement proposals generated in {}/",
            "✓".green(),
            "amber_proposals/".cyan()
        );
    }

    // Phase 6: Policy enforcement
    let mut exit_code = 0;
    if let Some(policy) = &config.policy {
        let dep_names: HashSet<String> = deps.iter().map(|d| d.name.clone()).collect();
        let violations = policy.validate(&dep_names);
        if !violations.is_empty() {
            println!();
            println!("  {}", "Policy Violations".red().bold());
            for v in &violations {
                println!("    {} {}", "✗".red(), v.message());
            }
            if policy.strict {
                exit_code = 2;
            } else if exit_code == 0 {
                exit_code = 1;
            }
        }
    }

    // Non-zero exit if there are actionable findings above threshold
    if exit_code == 0 {
        let actionable = scores.iter().filter(|s| s.overall >= threshold).count();
        if actionable > 0 {
            exit_code = 1;
        }
    }

    Ok(exit_code)
}

fn print_banner() {
    println!();
    println!(
        "  {}  {} v{}",
        "◈".bright_yellow(),
        "A M B E R".bold().bright_yellow(),
        env!("CARGO_PKG_VERSION").dimmed()
    );
    println!(
        "  {}",
        "Autonomous Dependency Reduction Engine".dimmed().italic()
    );
    println!();
}

fn print_roadmap() {
    println!();
    println!("  {}", "Amber Internal Module Roadmap".bold().underline());
    println!();
    println!(
        "  {}",
        "Long-term vision: amber::* zero-dependency foundation".italic()
    );
    println!();

    let modules = [
        (
            "amber::collections",
            "Custom vector, map, set implementations",
        ),
        (
            "amber::math",
            "Numerical utilities, linear algebra primitives",
        ),
        (
            "amber::logging",
            "Structured logging without external crates",
        ),
        ("amber::json", "Minimal JSON serializer/deserializer"),
        (
            "amber::config",
            "Configuration file parsing (TOML, YAML subset)",
        ),
        ("amber::time", "Date/time handling without chrono"),
        ("amber::string", "String utilities, formatting, regex-lite"),
        ("amber::net", "HTTP client/server primitives"),
        ("amber::path", "Cross-platform path manipulation"),
        ("amber::encoding", "Base64, hex, URL encoding"),
        ("amber::hash", "Hash maps, bloom filters, checksums"),
        ("amber::sync", "Lock-free data structures, channels"),
        ("amber::error", "Error types and propagation utilities"),
        ("amber::testing", "Property testing, fuzz harnesses"),
    ];

    for (name, desc) in modules {
        println!(
            "  {}  {}  {}",
            "◦".bright_yellow(),
            name.cyan().bold(),
            desc.dimmed()
        );
    }
    println!();
    println!(
        "  {}",
        "Each module is designed to replace commonly-overused external dependencies."
            .dimmed()
            .italic()
    );
    println!();
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;

    fn fixture_manifest(name: &str) -> PathBuf {
        let mut path = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        path.push("tests/fixtures");
        path.push(name);
        path.push("Cargo.toml");
        path
    }

    fn copy_fixture_to_temp(name: &str) -> tempfile::TempDir {
        let temp = tempfile::tempdir().unwrap();
        let src = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures")
            .join(name);
        fs::create_dir_all(temp.path().join("src")).unwrap();
        fs::copy(src.join("Cargo.toml"), temp.path().join("Cargo.toml")).unwrap();
        fs::copy(src.join("src/main.rs"), temp.path().join("src/main.rs")).unwrap();
        temp
    }

    #[test]
    fn run_list_command_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            manifest.parent().unwrap().to_str().unwrap(),
            "list",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_command_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_score_command_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            manifest.parent().unwrap().to_str().unwrap(),
            "score",
            "anyhow",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_replace_command_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "0",
            manifest.parent().unwrap().to_str().unwrap(),
            "replace",
            "anyhow",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_roadmap_command_succeeds() {
        let cli = Cli::parse_from(["amber", "roadmap"]);
        assert!(run(&cli, Path::new(".")).is_ok());
    }

    #[test]
    fn run_analyze_invalid_manifest_errors() {
        let cli = Cli::parse_from(["amber", "/nonexistent/path", "analyze"]);
        assert!(run(&cli, Path::new("/nonexistent/Cargo.toml")).is_err());
    }

    #[test]
    fn run_score_missing_crate_errors() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            manifest.parent().unwrap().to_str().unwrap(),
            "score",
            "not_present",
        ]);
        assert!(run(&cli, &manifest).is_err());
    }

    #[test]
    fn run_replace_below_threshold_returns_zero() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "replace",
            "anyhow",
        ]);
        assert_eq!(run(&cli, &manifest).unwrap(), 0);
    }

    #[test]
    fn run_analyze_actionable_returns_one() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "50",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert_eq!(run(&cli, &manifest).unwrap(), 1);
    }

    #[test]
    fn run_analyze_strict_policy_returns_two() {
        let temp = copy_fixture_to_temp("sample_project");
        fs::write(
            temp.path().join(".amber.toml"),
            r#"
[policy]
required = []
forbidden = ["anyhow"]
strict = true
"#,
        )
        .unwrap();
        let manifest = temp.path().join("Cargo.toml");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            temp.path().to_str().unwrap(),
            "analyze",
        ]);
        assert_eq!(run(&cli, &manifest).unwrap(), 2);
    }

    #[test]
    fn run_analyze_with_propose_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            "--propose",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_sarif_format_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "sarif",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn load_config_parses_valid_policy() {
        let temp = tempfile::tempdir().unwrap();
        let config_path = temp.path().join(".amber.toml");
        fs::write(
            &config_path,
            r#"
[policy]
required = []
forbidden = ["bad_crate"]
strict = true
"#,
        )
        .unwrap();
        let cli = Cli::parse_from(["amber"]);
        let config = load_config(&cli, &config_path).unwrap();
        assert!(config.policy.unwrap().is_forbidden("bad_crate"));
    }

    #[test]
    fn load_config_returns_error_for_invalid_toml() {
        let temp = tempfile::tempdir().unwrap();
        let config_path = temp.path().join(".amber.toml");
        fs::write(&config_path, "not valid toml").unwrap();
        let cli = Cli::parse_from(["amber"]);
        assert!(load_config(&cli, &config_path).is_err());
    }

    #[test]
    fn execute_roadmap_command_succeeds() {
        let cli = Cli::parse_from(["amber", "roadmap"]);
        assert!(execute(&cli).is_ok());
    }

    #[test]
    fn execute_list_command_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            manifest.parent().unwrap().to_str().unwrap(),
            "list",
        ]);
        assert!(execute(&cli).is_ok());
    }

    #[cfg(feature = "online")]
    #[test]
    fn online_flag_uses_online_provider_without_panic() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--online",
            manifest.parent().unwrap().to_str().unwrap(),
            "list",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn execute_errors_on_invalid_manifest() {
        let cli = Cli::parse_from(["amber", "/nonexistent/path", "list"]);
        assert!(execute(&cli).is_err());
    }

    #[test]
    fn run_no_subcommand_runs_analysis() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_writes_json_to_output_path() {
        let temp = tempfile::tempdir().unwrap();
        let output = temp.path().join("report.json");
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "json",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
            "--output",
            output.to_str().unwrap(),
        ]);
        assert!(run(&cli, &manifest).is_ok());
        assert!(output.exists());
    }

    #[test]
    fn run_analyze_writes_pr_to_output_path() {
        let temp = tempfile::tempdir().unwrap();
        let output = temp.path().join("report.md");
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "pr",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
            "--output",
            output.to_str().unwrap(),
        ]);
        assert!(run(&cli, &manifest).is_ok());
        assert!(output.exists());
    }

    #[test]
    fn run_analyze_writes_sarif_to_output_path() {
        let temp = tempfile::tempdir().unwrap();
        let output = temp.path().join("report.sarif");
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "sarif",
            "--threshold",
            "0",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
            "--output",
            output.to_str().unwrap(),
        ]);
        assert!(run(&cli, &manifest).is_ok());
        assert!(output.exists());
    }

    #[test]
    fn run_analyze_with_propose_generates_proposals() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "0",
            "--propose",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_empty_deps_returns_zero() {
        let temp = tempfile::tempdir().unwrap();
        std::fs::write(
            temp.path().join("Cargo.toml"),
            "[package]\nname = 'empty'\nversion = '0.1.0'\n",
        )
        .unwrap();
        std::fs::create_dir(temp.path().join("src")).unwrap();
        std::fs::write(temp.path().join("src/main.rs"), "fn main() {}").unwrap();
        let manifest = temp.path().join("Cargo.toml");
        let cli = Cli::parse_from(["amber", temp.path().to_str().unwrap(), "analyze"]);
        assert_eq!(run(&cli, &manifest).unwrap(), 0);
    }

    #[test]
    fn execute_trace_filter_initializes() {
        let cli = Cli::parse_from(["amber", "-vv", "roadmap"]);
        assert!(execute(&cli).is_ok());
    }

    #[test]
    fn run_analyze_json_to_stdout_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "json",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_pr_to_stdout_succeeds() {
        let manifest = fixture_manifest("sample_project");
        let cli = Cli::parse_from([
            "amber",
            "--format",
            "pr",
            "--threshold",
            "100",
            manifest.parent().unwrap().to_str().unwrap(),
            "analyze",
        ]);
        assert!(run(&cli, &manifest).is_ok());
    }

    #[test]
    fn run_analyze_non_strict_policy_returns_one() {
        let temp = copy_fixture_to_temp("sample_project");
        fs::write(
            temp.path().join(".amber.toml"),
            r#"
[policy]
required = []
forbidden = ["anyhow"]
strict = false
"#,
        )
        .unwrap();
        let manifest = temp.path().join("Cargo.toml");
        let cli = Cli::parse_from([
            "amber",
            "--threshold",
            "100",
            temp.path().to_str().unwrap(),
            "analyze",
        ]);
        assert_eq!(run(&cli, &manifest).unwrap(), 1);
    }
}
