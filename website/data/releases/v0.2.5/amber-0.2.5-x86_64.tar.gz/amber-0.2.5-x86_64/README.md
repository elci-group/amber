# Amber

**Amber** is an autonomous dependency-reduction engine for Rust. It analyzes a
Cargo project, detects how third-party crates are used, scores each dependency
for replaceability, and generates validated replacement proposals.

> **Status:** Production-oriented rewrite in progress. The current release
> focuses on accurate static analysis, clean architecture, and a warning-free
> toolchain.

## Features

- **Dependency inventory** — list direct and transitive dependencies with
  source, kind, and metadata.
- **AST-based usage analysis** — detect imports, function calls, method calls,
  macro invocations, type usage, and trait bounds.
- **Replaceability scoring** — multi-dimensional scoring across usage
  simplicity, transitive value, security safety, maintenance burden,
  testability, and API surface.
- **Replacement proposals** — generate drop-in replacement modules for common
  utility crates with validation strategies.
- **Multiple output formats** — console tables, JSON, PR-ready Markdown, and SARIF.
- **Live metadata** — optional crates.io integration via the `online` feature.
- **Policy enforcement** — `.amber.toml` config for required/forbidden crates and thresholds.
- **Validated replacements** — generated modules are checked with `cargo check`.

## Installation

```bash
cargo install --path .
```

## Usage

```bash
# Analyze the current project
amber

# Analyze a specific project
amber /path/to/project

# Output JSON
amber --format json

# Output SARIF for CI integration
amber --format sarif

# Exclude dev-dependencies and show transitive deps
amber --no-dev --transitive

# Generate replacement proposals for high-scoring crates
amber --propose --threshold 70

# Use live crates.io metadata (requires `online` feature)
amber --online

# Score a single crate
amber score anyhow

# Generate replacement code for a crate
amber replace anyhow --out-dir amber_out
```

## Configuration

Amber reads `.amber.toml` from the target project directory:

```toml
threshold = 60

[policy]
required = ["serde"]
forbidden = ["deprecated_crate"]
strict = false
```

## Architecture

```text
src/
├── analysis/      # Cargo metadata parsing and AST usage analysis
├── scoring/       # Replaceability scoring rules and classifier
├── replacement/   # Template-based replacement generation
└── reporting/     # Console, JSON, and PR formatters
```

## Development

```bash
# Build
cargo build

# Run tests
cargo test

# Lint
cargo clippy -- -D warnings

# Security audit
cargo audit
```

## License

MIT — see [LICENSE](LICENSE).
